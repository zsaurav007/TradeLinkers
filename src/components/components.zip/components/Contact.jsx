function Contact() {
  return (
    <div className="flex w-full flex-col items-center justify-between pl-6 text-center text-white md:w-[400px] md:flex-row md:text-left">
      <div>Tel: +88 017 1152 3638</div>
      <div>Email: tlc@tlcbd.com</div>
    </div>
  );
}
export default Contact;
