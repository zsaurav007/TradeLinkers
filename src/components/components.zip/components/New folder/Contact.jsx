function Contact(){
    return(
        <div className="flex pl-6 w-[400px] justify-between text-white items-center ">
            <div>Tel: +88 017 1152 3638</div>
            <div>Email: tlc@tlcbd.com</div>
        </div>
    );
}
export default Contact;