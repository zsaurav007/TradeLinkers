import React from "react";

const Search = () => {
  return (
    <div className="">
      <button className=" text-gray-500">
        <i className="fas fa-search"></i>
      </button>
    </div>
  );
};

export default Search;
